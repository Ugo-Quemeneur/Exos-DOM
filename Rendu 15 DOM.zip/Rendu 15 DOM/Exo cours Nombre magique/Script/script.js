// let magic;
// let guess = 0;
// let j;

// do {
//     magic = parseInt(Math.random() *10);
//     do {
//         guess =  parseInt(prompt("Entrez un nombre"))
//         if (guess < magic) {
//             alert("Plus grand");
//         }
//         if (guess > magic) {
//             alert("Plus petit");
//         }
//     } 
//     while (guess != magic);

//     alert("Bravo !");
//     j = confirm("Voulez-vous rejouer ?");
// } 
// while (j == true);

let magic = parseInt(Math.random() *10);
let guess = 0;
let j;

function verif() {
    guess =  getElementById.labell
    if (guess < magic) {
        alert("Plus grand");
    }
    if (guess > magic) {
        alert("Plus petit");
    }
}

do {
    magic
    do {
        
    } 
    while (guess != magic);

    alert("Bravo !");
    j = confirm("Voulez-vous rejouer ?");
} 
while (j == true);